import { errorToast } from "../components/ToastMessage/ToastMessage";
import Api from "../utils/Api";

export const fetchPhd = async () => {
  try {
    const { data } = await Api("/apps/references/phd/");
    return data;
  } catch (error) {
    errorToast(error.message);
  }
};

export const createPhd = async (body) => {
  const { data } = await Api.post("/apps/references/phd/", body);
  return data;
};

export const updatePhd = async (id, body) => {
  const { data } = await Api.put(`/apps/references/phd/update/${id}`, body);
  return data;
};
