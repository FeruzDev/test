import { errorToast } from "../components/ToastMessage/ToastMessage";
import Api from "../utils/Api";

export const fetchForeignLanguages = async () => {
  try {
    const { data } = await Api("/apps/references/foreign_languages/");
    return data;
  } catch (error) {
    errorToast(error.message);
  }
};

export const createForeignLanguages = async (body) => {
  const { data } = await Api.post("/apps/references/foreign_languages/", body);
  return data;
};

export const updateForeignLanguages = async (id, body) => {
  const { data } = await Api.put(
    `/apps/references/foreign_languages/update/${id}`,
    body
  );
  return data;
};
