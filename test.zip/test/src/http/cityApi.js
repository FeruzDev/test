import { errorToast } from "../components/ToastMessage/ToastMessage";
import Api from "../utils/Api";

export const fetchCity = async () => {
  try {
    const { data } = await Api("/apps/references/city/");
    return data;
  } catch (error) {
    errorToast(error.message);
  }
};

export const createCity = async (body) => {
  const { data } = await Api.post("/apps/references/city/", body);
  return data;
};

export const updateCity = async (id, body) => {
  const { data } = await Api.put(`/apps/references/city/update/${id}`, body);
  return data;
};
