import { errorToast } from "../components/ToastMessage/ToastMessage";
import Api from "../utils/Api";

export const fetchCertificate = async () => {
  try {
    const { data } = await Api("/apps/references/certificate/");
    return data;
  } catch (error) {
    errorToast(error.message);
  }
};

export const createCertificate = async (body) => {
  const { data } = await Api.post("/apps/references/certificate/", body);
  return data;
};

export const updateCertificate = async (id, body) => {
  const { data } = await Api.put(
    `/apps/references/certificate/update/${id}`,
    body
  );
  return data;
};
