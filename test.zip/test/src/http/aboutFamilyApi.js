import { errorToast } from "../components/ToastMessage/ToastMessage";
import Api from "../utils/Api";

export const fetchAboutFamily = async () => {
  try {
    const { data } = await Api("/apps/references/about_family/");
    return data;
  } catch (error) {
    errorToast(error.message);
  }
};

export const createAboutFamily = async (body) => {
  const { data } = await Api.post("/apps/references/about_family/", body);
  return data;
};

export const updateAboutFamily = async (id, body) => {
  const { data } = await Api.put(
    `/appsreferences/about_family/udate/${id}`,
    body
  );
  return data;
};
