import { errorToast } from "../components/ToastMessage/ToastMessage";
import Api from "../utils/Api";

export const fetchTypeOfCompetency = async () => {
  try {
    const { data } = await Api("/apps/references/type_of_competency/");
    return data;
  } catch (error) {
    errorToast(error.message);
  }
};

export const createTypeOfCompetency = async (body) => {
  const { data } = await Api.post("/apps/references/type_of_competency/", body);
  return data;
};

export const updateTypeOfCompetency = async (id, body) => {
  const { data } = await Api.put(
    `/apps/references/type_of_competency/update/${id}`,
    body
  );
  return data;
};
