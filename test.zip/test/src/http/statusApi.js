import { errorToast } from "../components/ToastMessage/ToastMessage";
import Api from "../utils/Api";

export const fetchStatus = async () => {
  try {
    const { data } = await Api("/apps/references/status/");
    return data;
  } catch (error) {
    errorToast(error.message);
  }
};

export const createStatus = async (body) => {
  const { data } = await Api.post("/apps/references/status/", body);
  return data;
};

export const updateStatus = async (id, body) => {
  const { data } = await Api.put(`/apps/references/status/update/${id}`, body);
  return data;
};
