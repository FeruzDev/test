import { errorToast } from "../components/ToastMessage/ToastMessage";
import Api from "../utils/Api";

export const fetchBachelor = async () => {
  try {
    const { data } = await Api("/apps/references/bachelor/");
    return data;
  } catch (error) {
    errorToast(error.message);
  }
};

export const createBachelor = async (body) => {
  const { data } = await Api.post("/apps/references/bachelor/", body);
  return data;
};

export const updateBachelor = async (id, body) => {
  const { data } = await Api.put(
    `/apps/references/bachelor/update/${id}`,
    body
  );
  return data;
};
