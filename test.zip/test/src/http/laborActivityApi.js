import { errorToast } from "../components/ToastMessage/ToastMessage";
import Api from "../utils/Api";

export const fetchLaborActivity = async () => {
  try {
    const { data } = await Api("/apps/references/labor_activity/");
    return data;
  } catch (error) {
    errorToast(error.message);
  }
};

export const createLaborActivity = async (body) => {
  const { data } = await Api.post("/apps/references/labor_activity/", body);
  return data;
};

export const updateLaborActivity = async (id, body) => {
  const { data } = await Api.put(
    `/apps/references/labor_activity/update/${id}`,
    body
  );
  return data;
};
