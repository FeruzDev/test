import { errorToast } from "../components/ToastMessage/ToastMessage";
import Api from "../utils/Api";

export const fetchUserList = async () => {
  try {
    const { data } = await Api("/users/list/");
    return data;
  } catch (error) {
    errorToast(error.message);
  }
};

export const fetchUsers = async () => {
  try {
    const { data } = await Api("/users/");
    return data;
  } catch (error) {
    errorToast(error.message);
  }
};
