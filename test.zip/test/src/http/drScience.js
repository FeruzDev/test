import { errorToast } from "../components/ToastMessage/ToastMessage";
import Api from "../utils/Api";

export const fetchDrScience = async () => {
  try {
    const { data } = await Api("/apps/references/dr_science/");
    return data;
  } catch (error) {
    errorToast(error.message);
  }
};

export const createDrScience = async (body) => {
  const { data } = await Api.post("/apps/references/dr_science/", body);
  return data;
};

export const updateDrScience = async (id, body) => {
  const { data } = await Api.put(
    `/apps/references/dr_science/update/${id}`,
    body
  );
  return data;
};
