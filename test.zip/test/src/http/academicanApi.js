import { errorToast } from "../components/ToastMessage/ToastMessage";
import Api from "../utils/Api";

export const fetchAcademican = async () => {
  try {
    const { data } = await Api("/apps/references/academician/");
    return data;
  } catch (error) {
    errorToast(error.message);
  }
};

export const createAcademican = async (body) => {
  const { data } = await Api.post("/apps/references/academician/", body);
  return data;
};

export const updateAcademican = async (id, body) => {
  const { data } = await Api.put(
    `/apps/references/academician/update/${id}`,
    body
  );
  return data;
};
