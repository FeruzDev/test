import { errorToast } from "../components/ToastMessage/ToastMessage";
import Api from "../utils/Api";

export const fetchPosition = async () => {
  try {
    const { data } = await Api("/apps/references/position/");
    return data;
  } catch (error) {
    errorToast(error.message);
  }
};

export const createPosition = async (body) => {
  const { data } = await Api.post("/apps/references/position/", body);
  return data;
};

export const updatePosition = async (id, body) => {
  const { data } = await Api.put(
    `/apps/references/position/update/${id}`,
    body
  );
  return data;
};
