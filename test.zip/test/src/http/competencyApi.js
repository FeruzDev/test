import { errorToast } from "../components/ToastMessage/ToastMessage";
import Api from "../utils/Api";

export const fetchCompetency = async () => {
  try {
    const { data } = await Api("/apps/references/competency/");
    return data;
  } catch (error) {
    errorToast(error.message);
  }
};

export const createCompetency = async (body) => {
  const { data } = await Api.post("/apps/references/competency/", body);
  return data;
};

export const updateCompetency = async (id, body) => {
  const { data } = await Api.put(
    `/apps/references/competency/update/${id}`,
    body
  );
  return data;
};
