import { errorToast } from "../components/ToastMessage/ToastMessage";
import Api from "../utils/Api";

export const fetchFaculty = async () => {
  try {
    const { data } = await Api("/apps/references/faculty/");
    return data;
  } catch (error) {
    errorToast(error.message);
  }
};

export const createFaculty = async (body) => {
  const { data } = await Api.post("/apps/references/faculty/", body);
  return data;
};

export const updateFaculty = async (id, body) => {
  const { data } = await Api.put(`/apps/references/faculty/update/${id}`, body);
  return data;
};
