import { errorToast } from "../components/ToastMessage/ToastMessage";
import Api from "../utils/Api";

export const fetchConfilctOfInterest = async () => {
  try {
    const { data } = await Api("/apps/references/conflict_of_interest/");
    return data;
  } catch (error) {
    errorToast(error.message);
  }
};

export const createConfilctOfInterest = async (body) => {
  try {
    const { data } = await Api.post(
      "/apps/references/conflict_of_interest/",
      body
    );
    return data;
  } catch (error) {
    errorToast(error.message);
  }
};

export const updateConfilctOfInterest = async (id, body) => {
  try {
    const { data } = await Api.put(
      `/apps/references/conflict_of_interest/update/${id}`,
      body
    );
    return data;
  } catch (error) {
    errorToast(error.message);
  }
};
