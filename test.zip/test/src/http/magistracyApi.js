import { errorToast } from "../components/ToastMessage/ToastMessage";
import Api from "../utils/Api";

export const fetchMagistracy = async () => {
  try {
    const { data } = await Api("/apps/references/magistracy/");
    return data;
  } catch (error) {
    errorToast(error.message);
  }
};

export const createMagistracy = async (body) => {
  const { data } = await Api.post("/apps/references/magistracy/", body);
  return data;
};

export const updateMagistracy = async (id, body) => {
  const { data } = await Api.put(
    `/apps/references/magistracy/update/${id}`,
    body
  );
  return data;
};
