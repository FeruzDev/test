import React, { useEffect, useState } from "react";
import LoginPage from "./pages/LoginPage/LoginPage";
import Pages from "./pages/Pages";

const App = () => {
  const [isLoggeed, setIsLogged] = useState(null);
  const token = localStorage.getItem("auth_token");

  return token || isLoggeed ? (
    <Pages />
  ) : (
    <LoginPage setIsLoged={setIsLogged} />
  );
};

export default App;
