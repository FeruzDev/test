import React from 'react'

const FormInput = ({placeholder, onChange, type}) => {
  return <input type={type} placeholder={placeholder} onChange={onChange} className='w-[60%] h-[40px] p-[10px] rounded-[5px] outline-none mb-[20px] text-[14px]'/>
}

export default FormInput
