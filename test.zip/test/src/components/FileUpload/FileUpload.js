import React, { useEffect, useRef, useState } from "react";
import { IoAlertCircle } from "react-icons/io5";

const FileUpload = ({
  label,
  onChange,
  value,
  required,
  isValidate,
  isClear,
}) => {
  const [color, setColor] = useState(null);
  const uploadRef = useRef();

  useEffect(() => {
    if (isValidate) {
      if (!value) {
        setColor("red");
      }
    }
  }, [isValidate]);

  useEffect(() => {
    if (isClear) {
      uploadRef.current._valueTracker.setValue(null);
    }
  }, [isClear]);

  return (
    <div>
      <label
        className="text-[14px]  top-[-9px] left-[10px]  bg-[#fff] text-[#6B7280] flex items-center px-[5px]"
        htmlFor="file_input"
      >
        {label}:{" "}
        {required && (
          <IoAlertCircle style={{ marginLeft: "5px" }} color={color} />
        )}
      </label>
      <input
        className="block w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 cursor-pointer dark:text-gray-400 focus:outline-none dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400"
        id="file_input"
        type="file"
        onChange={(e) => {
          onChange(e);
          setColor("");
        }}
        ref={uploadRef}
      />
    </div>
  );
};

export default FileUpload;
