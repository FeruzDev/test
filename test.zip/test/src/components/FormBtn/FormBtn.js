import React from 'react'

const FormBtn = ({title, onClick}) => {
  return <button className='form_btn' onClick={onClick}>{title}</button>
}

export default FormBtn
