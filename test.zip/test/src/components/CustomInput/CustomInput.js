import React, { useEffect, useRef } from "react";
import { IoAlertCircle } from "react-icons/io5";

const CustomInput = ({
  label,
  onChange,
  type,
  basis,
  name,
  value,
  placeholder,
  required,
  isValidate,
}) => {
  const inputRef = useRef();

  const validateRequire = (val) => {
    if (required) {
      if (val.length < 1) {
        inputRef.current.style.border = "2px solid red";
      } else {
        inputRef.current.style.border = "";
      }
    }
  };

  useEffect(() => {
    if (isValidate) {
      validateRequire(value);
    }
  }, [isValidate]);

  return (
    <div className={`${basis ? basis : "w-full"}`}>
      <label
        htmlFor="floating_standard"
        className="text-[14px]  top-[-9px] left-[10px] px-[5px] bg-[#fff] text-[#6B7280] flex items-center"
      >
        {label}: {required && <IoAlertCircle style={{ marginLeft: "5px" }} />}
      </label>
      <input
        onBlur={(e) => validateRequire(e.target.value)}
        value={value}
        name={name}
        type={type ? type : "text"}
        onChange={(e) => {
          onChange(e);
          validateRequire(e.target.value);
        }}
        ref={inputRef}
        id="floating_outlined"
        className="block px-2.5 py-4 w-full h-[40px] text-sm text-gray-900 placeholder:opacity-40 bg-transparent rounded-lg border-1 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-[#2684ff] focus:shadow-[0_0_1px_#2684ff] peer"
        placeholder={placeholder}
      />
    </div>
  );
};

export default CustomInput;
