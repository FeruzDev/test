import { toast } from "react-toastify";

export const errorToast = (message, option = {}) =>
  toast.error(message, option);

export const warningToast = (message, option = {}) =>
  toast.warning(message, option);

export const successToast = (message, option = {}) =>
  toast.success(message, option);
