import React, { useEffect, useRef } from "react";
import DatePicker from "react-datepicker";
import { IoAlertCircle, IoCalendarNumber } from "react-icons/io5";
import "react-datepicker/dist/react-datepicker.css";

const CustomDatePicker = ({
  value,
  onChange,
  label,
  basis,
  required,
  isValidate,
}) => {
  const dateRef = useRef();

  const validateRequire = (e) => {
    if (required) {
      if (!e) {
        dateRef.current.input.style.border = "2px solid red";
        dateRef.current.input.style.boxShadow = "none";
        dateRef.current.input.style.outline = "none";
      } else {
        dateRef.current.input.style.border = "";
        dateRef.current.input.style.boxShadow = "";
        dateRef.current.input.style.outline = "";
      }
    }
  };

  useEffect(() => {
    if (isValidate) {
      validateRequire(value);
    }
  }, [isValidate]);

  return (
    <div className={`group relative ${basis ? basis : "w-full"}`}>
      <span className="text-[14px]  top-[-9px] left-[10px]  bg-[#fff] text-[#6B7280] flex items-center">
        {label}: {required && <IoAlertCircle style={{ marginLeft: "5px" }} />}
      </span>
      <DatePicker
        selected={value}
        placeholderText={"Sanani tanlang..."}
        onChange={(e) => {
          onChange(e);
          dateRef.current.input.style.border = "";
        }}
        onBlur={(e) => validateRequire(e.target.value)}
        className={`text-[14px] w-full leading-[1.125rem] border border-[rgb(204_204_204)] h-[2.375rem] rounded-md p-[0.625rem] bg-white-900 outline-0 placeholder:opacity-60`}
        dateFormat={"dd.MM.yyyy"}
        ref={dateRef}
      />
      <IoCalendarNumber
        size={"0.625rem"}
        className="absolute top-[70%] translate-y-[-50%] right-[0.625rem] text-blue-200 pointer-events-none transition-all ease-in-out duration-200; group-hover:text-blue-500"
      />
    </div>
  );
};

export default CustomDatePicker;
