import React, { useEffect, useState } from "react";
import { createNation, updateNation } from "../../../http/nationApi";
import CustomInput from "../../CustomInput/CustomInput";
import { errorToast } from "../../ToastMessage/ToastMessage";

const NationModal = ({ value, type, closeModal, getDatas, mainModal }) => {
  const [nation, setNation] = useState((type === "edit" && value?.name) || "");

  const handleCreateNation = () => {
    createNation({
      name: nation,
    })
      .then(() => {
        closeModal();
        setNation("");
        getDatas();
      })
      .catch((error) => errorToast(error.message));
  };

  const handleEditNation = () => {
    updateNation(value.id, {
      name: nation,
    })
      .then(() => {
        closeModal();
        setNation("");
        getDatas();
      })
      .catch((error) => errorToast(error.message));
  };

  useEffect(() => {
    setNation((type === "edit" && value?.name) || "");
  }, [mainModal]);

  return (
    <div
      className="w-[600px] px-[20px] py-[25px] max-h-[300px] bg-[#fff] rounded-lg"
      onClick={(e) => e.stopPropagation()}
    >
      <CustomInput
        value={nation}
        onChange={(e) => setNation(e.target.value)}
        label="Davlatni yozing"
      />
      <div className="mt-[20px] w-full flex justify-center">
        <button
          className="bg-blue-600 text-[16px] font-bold text-white py-[10px] px-[15px] rounded-[5px] sm:w-auto w-[80%]"
          onClick={(e) => {
            e.preventDefault();
            (type === "create" && handleCreateNation()) ||
              (type === "edit" && handleEditNation());
          }}
        >
          Qo'shish
        </button>
      </div>
    </div>
  );
};

export default NationModal;
