import React, { useEffect, useState } from "react";
import { createAboutFamily } from "../../../http/aboutFamilyApi";
import { fetchCity } from "../../../http/cityApi";
import { changeDateFormat } from "../../../pages/CreateEmployee/utils/utils";
import CustomInput from "../../CustomInput/CustomInput";
import CustomSelect from "../../CustomSelect/CustomSelect";
import CustomDatePicker from "../../DatePicker/CustomDatePicker";
import { errorToast } from "../../ToastMessage/ToastMessage";

const relatives = [
  {
    label: "Otasi",
    value: "father",
  },
  {
    label: "Onasi",
    value: "mother",
  },
  {
    label: "Eri",
    value: "husband",
  },
  {
    label: "Xotini",
    value: "wife",
  },
  {
    label: "Bobosi",
    value: "grandpa",
  },
  {
    label: "Bibisi",
    value: "grandma",
  },
  {
    label: "Akasi",
    value: "brother",
  },
  {
    label: "Opasi",
    value: "sister",
  },
  {
    label: "Ukasi",
    value: "l_brother",
  },
  {
    label: "Singlisi",
    value: "l_sister",
  },
  {
    label: "O'g'li",
    value: "son",
  },
  {
    label: "Qizi",
    value: "daughter",
  },
  {
    label: "Qaynotasi",
    value: "father_in_husband",
  },
  {
    label: "Qaynonasi",
    value: "mother_in_husband",
  },
];

const AboutFamilyForm = ({ getDatas, closeModal, type, value }) => {
  console.log(value);
  const [relation, setRelation] = useState(null);
  const [fullName, setFullName] = useState(value?.full_name || "");
  const [birthdate, setBirthdate] = useState(
    new Date(value?.birth_date) || null
  );
  const [birthPlace, setBirthPlace] = useState(
    {
      label: `${value?.birth_place?.country?.name} - ${value?.birth_place?.name}`,
      value: value.id,
    } || null
  );
  const [residencePlace, setResidencePlace] = useState(
    {
      label: `${value?.place_residence?.country?.name} - ${value?.place_residence?.name}`,
      value: value.id,
    } || null
  );
  const [workPlace, setWorkPlace] = useState(value?.work_place || "");

  const [cityList, setCityList] = useState([]);

  useEffect(() => {
    fetchCity().then((data) =>
      setCityList(
        data.map((item) => ({
          ...item,
          label: `${item?.country?.name} - ${item?.name}`,
          value: item.id,
        }))
      )
    );
  }, []);

  const handleCreate = () => {
    createAboutFamily({
      relation_degree: relation?.value,
      full_name: fullName,
      birth_date: changeDateFormat(birthdate),
      birth_place_pk: birthPlace?.value,
      place_residence_pk: residencePlace?.value,
      work_place: workPlace,
    })
      .then(() => {
        setRelation(null);
        setFullName("");
        setBirthPlace(null);
        setBirthdate(null);
        setWorkPlace("");
        getDatas();
        closeModal();
      })
      .catch((error) => errorToast(error.message));
  };

  return (
    <div
      className="w-[600px] px-[20px] py-[25px] min-h-[300px] bg-[#fff] rounded-lg"
      onClick={(e) => e.stopPropagation()}
    >
      <div className="mb-[20px]">
        <CustomSelect
          value={relation}
          options={relatives}
          placeholder="Qarindosh"
          onChange={(e) => setRelation(e)}
          isNotEdited={true}
        />
      </div>
      <div className="mb-[20px]">
        <CustomInput
          value={fullName}
          onChange={(e) => setFullName(e.target.value)}
          label="F.I.O."
        />
      </div>
      <div className="mb-[20px]">
        <CustomDatePicker
          label={"Tug'ilgan yili"}
          value={birthdate}
          onChange={(e) => setBirthdate(e)}
          name="first_working_date"
        />
      </div>
      <div className="mb-[20px]">
        <CustomSelect
          value={birthPlace}
          options={cityList}
          placeholder="Tug'ilgan joyi"
          onChange={(e) => setBirthPlace(e)}
          isNotEdited={true}
        />
      </div>
      <div className="mb-[20px]">
        <CustomSelect
          value={residencePlace}
          options={cityList}
          placeholder="Yashash joyi"
          onChange={(e) => setResidencePlace(e)}
          isNotEdited={true}
        />
      </div>
      <div className="mb-[20px]">
        <CustomInput
          value={workPlace}
          onChange={(e) => setWorkPlace(e.target.value)}
          label="Ish joyi va lavozimi"
        />
      </div>
      <div className="w-full flex justify-center">
        <button
          className="bg-blue-600 text-[16px] font-bold text-white py-[10px] px-[15px] rounded-[5px] sm:w-auto w-[80%]"
          onClick={(e) => {
            e.preventDefault();
            handleCreate();
          }}
        >
          Qo'shish
        </button>
      </div>
    </div>
  );
};

export default AboutFamilyForm;
