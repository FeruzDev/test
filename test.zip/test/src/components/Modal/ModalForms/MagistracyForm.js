import React, { useEffect, useState } from "react";
import { createBachelor, updateBachelor } from "../../../http/bachelorApi";
import { createEdu, fetchEdu, updateEdu } from "../../../http/eduApi";
import {
  createFaculty,
  fetchFaculty,
  updateFaculty,
} from "../../../http/facultyApi";
import {
  createMagistracy,
  updateMagistracy,
} from "../../../http/magistracyApi";
import CustomInput from "../../CustomInput/CustomInput";
import CustomSelect from "../../CustomSelect/CustomSelect";
import { errorToast } from "../../ToastMessage/ToastMessage";

const UniversityForm = ({ value, closeModal, getDatas, type }) => {
  const [inputValue, setInputValue] = useState(value?.name || "");

  const handleCreateEdu = () => {
    createEdu({
      name: inputValue,
    })
      .then(() => {
        setInputValue("");
        closeModal();
        getDatas();
      })
      .catch((error) => errorToast(error.message));
  };

  const handleEditEdu = () => {
    updateEdu(value.id, {
      name: inputValue,
    })
      .then(() => {
        setInputValue("");
        closeModal();
        getDatas();
      })
      .catch((error) => errorToast(error.message));
  };

  return (
    <div
      className="w-[600px] px-[20px] py-[25px] max-h-[300px] bg-[#fff] rounded-lg"
      onClick={(e) => e.stopPropagation()}
    >
      <CustomInput
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
        label="Oliygohni yozing"
      />
      <div className="mt-[20px] w-full flex justify-center">
        <button
          className="bg-blue-600 text-[16px] font-bold text-white py-[10px] px-[15px] rounded-[5px] sm:w-auto w-[80%]"
          onClick={(e) => {
            e.preventDefault();
            (type === "create" && handleCreateEdu()) ||
              (type === "edit" && handleEditEdu());
          }}
        >
          Qo'shish
        </button>
      </div>
    </div>
  );
};

const FacultyForm = ({ value, type, closeModal, getDatas }) => {
  const [inputValue, setInputValue] = useState(
    (type === "edit" && value?.education?.graduate) || ""
  );
  const [selectValue, setSelectValue] = useState(
    (type === "edit" && {
      ...value,
      label: `${value?.education?.university?.name}`,
      value: value?.id,
    }) ||
      null
  );
  const [universityList, setUniversityList] = useState([]);
  console.log(value);
  const [modal, setModal] = useState(false);
  const [modalValue, setModalValue] = useState(null);
  const [typeModal, setTypeModal] = useState(null);

  const handleOpenModal = (_, val, type) => {
    setModalValue(val);
    setTypeModal(type);
    setModal(true);
  };

  useEffect(() => {
    fetchEdu().then((data) =>
      setUniversityList(
        data.map((item) => ({
          ...item,
          label: `${item?.name}`,
          value: item?.id,
        }))
      )
    );
  }, [modal]);

  const handleCreateFaculty = () => {
    createFaculty({
      university_pk: selectValue.value,
      graduate: inputValue,
    })
      .then(() => {
        setInputValue("");
        setSelectValue(null);
        closeModal();
        getDatas();
      })
      .catch((error) => errorToast(error.message));
  };

  const handleEditFaculty = () => {
    updateFaculty(value.id, {
      university_pk: selectValue.value,
      graduate: inputValue,
    })
      .then(() => {
        setInputValue("");
        setSelectValue(null);
        closeModal();
        getDatas();
      })
      .catch((error) => errorToast(error.message));
  };

  if (modal) {
    return (
      <UniversityForm
        closeModal={() => setModal(false)}
        type={typeModal}
        value={modalValue}
        getDatas={getDatas}
      />
    );
  }
  return (
    <div
      className="w-[600px] px-[20px] py-[25px] max-h-[300px] bg-[#fff] rounded-lg"
      onClick={(e) => e.stopPropagation()}
    >
      <CustomSelect
        value={selectValue}
        options={universityList}
        placeholder="Oliygoh tanlang"
        onChange={(e) => setSelectValue(e)}
        openModal={handleOpenModal}
      />
      <div className="mt-[30px]">
        <CustomInput
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          label="Yunalishni yozing"
        />
      </div>
      <div className="mt-[20px] w-full flex justify-center">
        <button
          className="bg-blue-600 text-[16px] font-bold text-white py-[10px] px-[15px] rounded-[5px] sm:w-auto w-[80%]"
          onClick={(e) => {
            e.preventDefault();
            (type === "create" && handleCreateFaculty()) ||
              (type === "edit" && handleEditFaculty());
          }}
        >
          Qo'shish
        </button>
      </div>
    </div>
  );
};

const MagistracyForm = ({
  value,
  type,
  closeModal,
  getDatas,
  closing,
  mainModal,
}) => {
  const [inputValue, setInputValue] = useState(
    (type === "edit" && value.period) || ""
  );
  const [selectValue, setSelectValue] = useState(
    (type === "edit" && {
      ...value,
      label: `${value?.education?.university?.name} - ${value?.education?.graduate}`,
      value: value?.education?.id,
    }) ||
      null
  );
  const [facultyList, setFacultyList] = useState([]);

  const [modal, setModal] = useState(false);
  const [modalValue, setModalValue] = useState(null);
  const [typeModal, setTypeModal] = useState(null);

  const handleOpenModal = (_, val, type) => {
    setModalValue(val);
    setTypeModal(type);
    setModal(true);
  };

  useEffect(() => {
    fetchFaculty().then((data) =>
      setFacultyList(
        data.map((item) => ({
          ...item,
          label: `${item?.university?.name} - ${item?.graduate}`,
          value: item?.id,
        }))
      )
    );
  }, [modal]);

  useEffect(() => {
    setInputValue((type === "edit" && value?.period) || "");
    setSelectValue(
      (type === "edit" && {
        ...value,
        label: `${value?.education?.university?.name} - ${value?.education?.graduate}`,
        value: value?.id,
      }) ||
        null
    );
  }, [mainModal]);

  useEffect(() => {
    setModal(false);
    setInputValue("");
    setSelectValue(null);
  }, [closing]);

  const handleCreateMagistracy = () => {
    createMagistracy({
      education_pk: selectValue.value,
      period: inputValue,
    })
      .then(() => {
        setInputValue("");
        setSelectValue(null);
        closeModal();
        getDatas();
      })
      .catch((error) => errorToast(error.message));
  };

  const handleEditMagistracy = () => {
    updateMagistracy(value.id, {
      education_pk: selectValue.value,
      period: inputValue,
    })
      .then(() => {
        setInputValue("");
        setSelectValue(null);
        closeModal();
        getDatas();
      })
      .catch((error) => errorToast(error.message));
  };

  if (modal) {
    return (
      <FacultyForm
        closeModal={() => setModal(false)}
        type={typeModal}
        value={modalValue}
        getDatas={getDatas}
      />
    );
  }
  return (
    <>
      <div
        className="w-[600px] px-[20px] py-[25px] max-h-[300px] bg-[#fff] rounded-lg"
        onClick={(e) => e.stopPropagation()}
      >
        <CustomSelect
          value={selectValue}
          options={facultyList}
          placeholder="Fakultet tanlang"
          onChange={(e) => setSelectValue(e)}
          openModal={handleOpenModal}
        />
        <div className="mt-[30px]">
          <CustomInput
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            label="Davrni yozing"
          />
        </div>
        <div className="mt-[20px] w-full flex justify-center">
          <button
            className="bg-blue-600 text-[16px] font-bold text-white py-[10px] px-[15px] rounded-[5px] sm:w-auto w-[80%]"
            onClick={(e) => {
              e.preventDefault();
              (type === "create" && handleCreateMagistracy()) ||
                (type === "edit" && handleEditMagistracy());
            }}
          >
            Qo'shish
          </button>
        </div>
      </div>
    </>
  );
};

export default MagistracyForm;
