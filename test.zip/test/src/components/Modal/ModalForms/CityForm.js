import React, { useEffect, useState } from "react";
import { createCity, updateCity } from "../../../http/cityApi";
import {
  createCountry,
  fetchCountry,
  updateCountry,
} from "../../../http/countryApi";
import CustomInput from "../../CustomInput/CustomInput";
import CustomSelect from "../../CustomSelect/CustomSelect";
import { errorToast } from "../../ToastMessage/ToastMessage";

const CountryForm = ({ value, closeModal, type, getDatas }) => {
  const [country, setCountry] = useState(value?.name);

  const handleCreateCountry = () => {
    createCountry({
      name: country,
    })
      .then(() => {
        closeModal();
        setCountry("");
        getDatas();
      })
      .catch((error) => errorToast(error.message));
  };

  const handleEditCountry = () => {
    updateCountry(value.value, {
      name: country,
    })
      .then(() => {
        closeModal();
        setCountry("");
        getDatas();
      })
      .catch((error) => errorToast(error.message));
  };

  return (
    <div
      className="w-[600px] px-[20px] py-[25px] max-h-[300px] bg-[#fff] rounded-lg"
      onClick={(e) => e.stopPropagation()}
    >
      <CustomInput
        value={country}
        onChange={(e) => setCountry(e.target.value)}
        label="Davlatni yozing"
      />
      <div className="mt-[20px] w-full flex justify-center">
        <button
          className="bg-blue-600 text-[16px] font-bold text-white py-[10px] px-[15px] rounded-[5px] sm:w-auto w-[80%]"
          onClick={(e) => {
            e.preventDefault();
            (type === "create" && handleCreateCountry()) ||
              (type === "edit" && handleEditCountry());
          }}
        >
          Qo'shish
        </button>
      </div>
    </div>
  );
};

const CityForm = ({
  value,
  type,
  closeModal,
  getDatas,
  closing,
  mainModal,
}) => {
  const [inputValue, setInputValue] = useState(value?.name || "");
  const [selectValue, setSelectValue] = useState(
    (type === "edit" && {
      ...value,
      label: value?.country?.name,
      value: value?.country?.id,
    }) ||
      null
  );
  const [countryList, setCountryList] = useState([]);

  const [modal, setModal] = useState(false);
  const [modalValue, setModalValue] = useState(null);
  const [typeModal, setTypeModal] = useState(null);

  const handleOpenModal = (_, val, type) => {
    setModalValue(val);
    setTypeModal(type);
    setModal(true);
  };

  useEffect(() => {
    setInputValue(value?.name || "");
    setSelectValue(
      (type === "edit" && {
        label: value?.country?.name,
        value: value?.country?.id,
      }) ||
        null
    );
  }, [mainModal]);

  useEffect(() => {
    fetchCountry().then((data) =>
      setCountryList(
        data.map((item) => ({ ...item, label: item.name, value: item.id }))
      )
    );
  }, [modal]);

  useEffect(() => {
    setModal(false);
    setInputValue("");
    setSelectValue(null);
  }, [closing]);

  const handleCreateCity = () => {
    createCity({
      country_pk: selectValue.id,
      name: inputValue,
    })
      .then(() => {
        setInputValue("");
        setSelectValue(null);
        closeModal();
        getDatas();
      })
      .catch((error) => errorToast(error.message));
  };

  const handleEditCity = () => {
    updateCity(value.id, {
      country_pk: value?.country?.id,
      name: inputValue,
    })
      .then(() => {
        setInputValue("");
        setSelectValue(null);
        closeModal();
        getDatas();
      })
      .catch((error) => errorToast(error.message));
  };
  console.log(inputValue);
  if (modal) {
    return (
      <CountryForm
        closeModal={() => setModal(false)}
        type={typeModal}
        value={modalValue}
        getDatas={getDatas}
      />
    );
  }
  return (
    <>
      <div
        className="w-[600px] px-[20px] py-[25px] max-h-[300px] bg-[#fff] rounded-lg"
        onClick={(e) => e.stopPropagation()}
      >
        <CustomSelect
          value={selectValue}
          options={countryList}
          placeholder="Davlat tanlang"
          onChange={(e) => setSelectValue(e)}
          openModal={handleOpenModal}
        />
        <div className="mt-[30px]">
          <CustomInput
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            label="Shahar yozing"
          />
        </div>
        <div className="mt-[20px] w-full flex justify-center">
          <button
            className="bg-blue-600 text-[16px] font-bold text-white py-[10px] px-[15px] rounded-[5px] sm:w-auto w-[80%]"
            onClick={(e) => {
              e.preventDefault();
              (type === "create" && handleCreateCity()) ||
                (type === "edit" && handleEditCity());
            }}
          >
            Qo'shish
          </button>
        </div>
      </div>
    </>
  );
};

export default CityForm;
