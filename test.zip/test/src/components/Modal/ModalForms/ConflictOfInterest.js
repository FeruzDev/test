import React from "react";
import {
  createConfilctOfInterest,
  updateConfilctOfInterest,
} from "../../../http/conflictOfInterestApi";

const ConflictOfInterest = () => {
  const [name, setName] = useState(value?.name || "");
  const [reason, setReason] = useState(value?.person || "");

  const handleCreate = () => {
    createConfilctOfInterest({
      name: certificate,
      person: person,
    })
      .then(() => {
        closeModal();
        getDatas();
        setCertificate("");
        setPerson("");
      })
      .catch((error) => errorToast(error.message));
  };

  const handleEdit = () => {
    updateConfilctOfInterest(value?.id, {
      name: certificate,
      person: person,
    })
      .then(() => {
        closeModal();
        getDatas();
        setCertificate("");
        setPerson("");
      })
      .catch((error) => errorToast(error.message));
  };

  return (
    <div
      className="w-[600px] px-[20px] py-[25px] min-h-[300px] bg-[#fff] rounded-lg"
      onClick={(e) => e.stopPropagation()}
    >
      <div className="mb-[20px]">
        <CustomInput
          value={certificate}
          onChange={(e) => setCertificate(e.target.value)}
          label="Obyektning nomi"
        />
      </div>
      <div className="mb-[20px]">
        <CustomInput
          value={person}
          onChange={(e) => setPerson(e.target.value)}
          label="Sabab"
        />
      </div>
      <div className="w-full flex justify-center">
        <button
          className="bg-blue-600 text-[16px] font-bold text-white py-[10px] px-[15px] rounded-[5px] sm:w-auto w-[80%]"
          onClick={(e) => {
            e.preventDefault();
            (type === "create" && handleCreate()) ||
              (type === "edit" && handleEdit());
          }}
        >
          Qo'shish
        </button>
      </div>
    </div>
  );
};

export default ConflictOfInterest;
