import React, { useEffect, useState } from "react";
import { createNation, updateNation } from "../../../http/nationApi";
import { createPosition, updatePosition } from "../../../http/positionApi";
import CustomInput from "../../CustomInput/CustomInput";
import { errorToast } from "../../ToastMessage/ToastMessage";

const WorkPosForm = ({ value, type, closeModal, getDatas, mainModal }) => {
  const [workPos, setWorkPos] = useState(
    (type === "edit" && value?.name) || ""
  );

  const handleCreatePosition = () => {
    createPosition({
      name: workPos,
    })
      .then(() => {
        closeModal();
        setWorkPos("");
        getDatas();
      })
      .catch((error) => errorToast(error.message));
  };

  const handleEditPosition = () => {
    updatePosition(value.id, {
      name: workPos,
    })
      .then(() => {
        closeModal();
        setWorkPos("");
        getDatas();
      })
      .catch((error) => errorToast(error.message));
  };

  useEffect(() => {
    setWorkPos((type === "edit" && value?.name) || "");
  }, [mainModal]);

  return (
    <div
      className="w-[600px] px-[20px] py-[25px] max-h-[300px] bg-[#fff] rounded-lg"
      onClick={(e) => e.stopPropagation()}
    >
      <CustomInput
        value={workPos}
        onChange={(e) => setWorkPos(e.target.value)}
        label="Lavozimni yozing"
      />
      <div className="mt-[20px] w-full flex justify-center">
        <button
          className="bg-blue-600 text-[16px] font-bold text-white py-[10px] px-[15px] rounded-[5px] sm:w-auto w-[80%]"
          onClick={(e) => {
            e.preventDefault();
            (type === "create" && handleCreatePosition()) ||
              (type === "edit" && handleEditPosition());
          }}
        >
          Qo'shish
        </button>
      </div>
    </div>
  );
};

export default WorkPosForm;
