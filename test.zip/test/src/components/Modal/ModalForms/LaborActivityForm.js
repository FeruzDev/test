import React, { useEffect, useState } from "react";
import {
  createLaborActivity,
  updateLaborActivity,
} from "../../../http/laborActivityApi";
import CustomInput from "../../CustomInput/CustomInput";
import { errorToast } from "../../ToastMessage/ToastMessage";

function LaborActivityForm({ value, type, getDatas, closeModal, mainModal }) {
  const [activity, setActivity] = useState(value?.name || "");
  console.log(value);
  const handleCreateNation = () => {
    createLaborActivity({
      name: activity,
    })
      .then(() => {
        closeModal();
        setActivity("");
        getDatas();
      })
      .catch((error) => errorToast(error.message));
  };

  const handleEditNation = () => {
    updateLaborActivity(value.id, {
      name: activity,
    })
      .then(() => {
        closeModal();
        setActivity("");
        getDatas();
      })
      .catch((error) => errorToast(error.message));
  };

  useEffect(() => {
    setActivity(value?.name || "");
  }, [mainModal]);

  return (
    <div
      className="w-[600px] px-[20px] py-[25px] max-h-[300px] bg-[#fff] rounded-lg"
      onClick={(e) => e.stopPropagation()}
    >
      <CustomInput
        value={activity}
        onChange={(e) => setActivity(e.target.value)}
        label="Davlatni yozing"
      />
      <div className="mt-[20px] w-full flex justify-center">
        <button
          className="bg-blue-600 text-[16px] font-bold text-white py-[10px] px-[15px] rounded-[5px] sm:w-auto w-[80%]"
          onClick={(e) => {
            e.preventDefault();
            (type === "create" && handleCreateNation()) ||
              (type === "edit" && handleEditNation());
          }}
        >
          Qo'shish
        </button>
      </div>
    </div>
  );
}

export default LaborActivityForm;
