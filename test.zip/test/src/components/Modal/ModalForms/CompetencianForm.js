import React, { useEffect, useState } from "react";
import {
  createCompetency,
  updateCompetency,
} from "../../../http/competencyApi";
import {
  createTypeOfCompetency,
  fetchTypeOfCompetency,
} from "../../../http/typeOfCompetencyApi";
import CustomInput from "../../CustomInput/CustomInput";
import CustomSelect from "../../CustomSelect/CustomSelect";
import { errorToast } from "../../ToastMessage/ToastMessage";

const TypeCompForm = ({ value, type, closeModal, getDatas, mainModal }) => {
  const [typeCode, setTypeCode] = useState(value?.name || "");

  const handleCreate = () => {
    createCompetency({
      name: typeCode,
    })
      .then(() => {
        closeModal();
        setTypeCode("");
        getDatas();
      })
      .catch((error) => errorToast(error.message));
  };

  const handleEdit = () => {
    updateCompetency(value.id, {
      name: typeCode,
    })
      .then(() => {
        closeModal();
        setTypeCode("");
        getDatas();
      })
      .catch((error) => errorToast(error.message));
  };

  useEffect(() => {
    setTypeCode(value?.name || "");
  }, []);

  return (
    <div
      className="w-[600px] px-[20px] py-[25px] max-h-[300px] bg-[#fff] rounded-lg"
      onClick={(e) => e.stopPropagation()}
    >
      <CustomInput
        value={typeCode}
        onChange={(e) => setTypeCode(e.target.value)}
        label="Kompetensiya turini yozing"
      />
      <div className="mt-[20px] w-full flex justify-center">
        <button
          className="bg-blue-600 text-[16px] font-bold text-white py-[10px] px-[15px] rounded-[5px] sm:w-auto w-[80%]"
          onClick={(e) => {
            e.preventDefault();
            (type === "create" && handleCreate()) ||
              (type === "edit" && handleEdit());
          }}
        >
          Qo'shish
        </button>
      </div>
    </div>
  );
};

const CompetencianForm = ({
  value,
  type,
  closeModal,
  getDatas,
  closing,
  mainModal,
}) => {
  console.log(value);
  const [inputValue, setInputValue] = useState(value?.name_code || "");
  const [selectValue, setSelectValue] = useState(
    (type === "edit" && {
      ...value,
      label: `${value?.code?.name}`,
      value: value?.code?.id,
    }) ||
      null
  );
  const [comeptencyList, setCompetencyList] = useState([]);

  const [modal, setModal] = useState(false);
  const [modalValue, setModalValue] = useState(null);
  const [typeModal, setTypeModal] = useState(null);

  const handleOpenModal = (_, val, type) => {
    setModalValue(val);
    setTypeModal(type);
    setModal(true);
  };
  useEffect(() => {
    fetchTypeOfCompetency().then((data) =>
      setCompetencyList(
        data.map((item) => ({ ...item, label: item.name, value: item.id }))
      )
    );
  }, [modal]);

  useEffect(() => {
    setInputValue(value?.name_code || "");
    setSelectValue(
      (type === "edit" && {
        ...value,
        label: `${value?.code?.name}`,
        value: value?.code?.id,
      }) ||
        null
    );
  }, [mainModal]);
  console.log(selectValue);
  useEffect(() => {
    setModal(false);
    setInputValue("");
    setSelectValue(null);
  }, [closing]);

  const handleCreate = () => {
    createCompetency({
      code_pk: selectValue.id,
      name_code: inputValue,
    })
      .then(() => {
        setInputValue("");
        setSelectValue(null);
        closeModal();
        getDatas();
      })
      .catch((error) => errorToast(error.message));
  };

  const handleEdit = () => {
    updateCompetency(value.id, {
      code_pk: selectValue.id,
      name_code: inputValue,
    })
      .then(() => {
        setInputValue("");
        setSelectValue(null);
        closeModal();
        getDatas();
      })
      .catch((error) => errorToast(error.message));
  };

  if (modal) {
    return (
      <TypeCompForm
        closeModal={() => setModal(false)}
        type={typeModal}
        value={modalValue}
        getDatas={getDatas}
      />
    );
  }
  return (
    <div
      className="w-[600px] px-[20px] py-[25px] max-h-[300px] bg-[#fff] rounded-lg"
      onClick={(e) => e.stopPropagation()}
    >
      <CustomSelect
        value={selectValue}
        options={comeptencyList}
        placeholder="Kompetensiya turi tanlang"
        onChange={(e) => setSelectValue(e)}
        openModal={handleOpenModal}
      />
      <div className="mt-[30px]">
        <CustomInput
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          label="Kompetensiya kodini yozing"
        />
      </div>
      <div className="mt-[20px] w-full flex justify-center">
        <button
          className="bg-blue-600 text-[16px] font-bold text-white py-[10px] px-[15px] rounded-[5px] sm:w-auto w-[80%]"
          onClick={(e) => {
            e.preventDefault();
            (type === "create" && handleCreate()) ||
              (type === "edit" && handleEdit());
          }}
        >
          Qo'shish
        </button>
      </div>
    </div>
  );
};

export default CompetencianForm;
