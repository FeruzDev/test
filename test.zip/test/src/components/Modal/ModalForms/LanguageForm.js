import React, { useEffect, useState } from "react";
import {
  createForeignLanguages,
  updateForeignLanguages,
} from "../../../http/foreignLanguages";
import CustomInput from "../../CustomInput/CustomInput";
import { errorToast } from "../../ToastMessage/ToastMessage";

const LanguageForm = ({ value, type, closeModal, getDatas, mainModal }) => {
  console.log(value);
  const [language, setLanguage] = useState(value?.lang || "");

  const handleCreate = () => {
    createForeignLanguages({
      lang: language,
    })
      .then(() => {
        closeModal();
        setLanguage("");
        getDatas();
      })
      .catch((error) => errorToast(error.message));
  };

  const handleEdit = () => {
    updateForeignLanguages(value.id, {
      lang: language,
    })
      .then(() => {
        closeModal();
        setLanguage("");
        getDatas();
      })
      .catch((error) => errorToast(error.message));
  };

  useEffect(() => {
    setLanguage(value?.lang || "");
  }, [mainModal]);

  return (
    <div
      className="w-[600px] px-[20px] py-[25px] max-h-[300px] bg-[#fff] rounded-lg"
      onClick={(e) => e.stopPropagation()}
    >
      <CustomInput
        value={language}
        onChange={(e) => setLanguage(e.target.value)}
        label="Tilni yozing"
      />
      <div className="mt-[20px] w-full flex justify-center">
        <button
          className="bg-blue-600 text-[16px] font-bold text-white py-[10px] px-[15px] rounded-[5px] sm:w-auto w-[80%]"
          onClick={(e) => {
            e.preventDefault();
            (type === "create" && handleCreate()) ||
              (type === "edit" && handleEdit());
          }}
        >
          Qo'shish
        </button>
      </div>
    </div>
  );
};

export default LanguageForm;
