import React, { useState } from "react";
import { createStatus, updateStatus } from "../../../http/statusApi";
import CustomInput from "../../CustomInput/CustomInput";
import { errorToast } from "../../ToastMessage/ToastMessage";

const StatusForm = ({ value, type, getDatas, closeModal }) => {
  const [status, setStatus] = useState(value?.name || "");

  const handleCreate = () => {
    createStatus({
      name: status,
    })
      .then(() => {
        closeModal();
        setStatus("");
        getDatas();
      })
      .catch((error) => errorToast(error.message));
  };

  const handleEdit = () => {
    updateStatus(value.id, {
      name: status,
    })
      .then(() => {
        closeModal();
        setStatus("");
        getDatas();
      })
      .catch((error) => errorToast(error.message));
  };

  return (
    <div
      className="w-[600px] px-[20px] py-[25px] max-h-[300px] bg-[#fff] rounded-lg"
      onClick={(e) => e.stopPropagation()}
    >
      <CustomInput
        value={status}
        onChange={(e) => setStatus(e.target.value)}
        label="Davlatni yozing"
      />
      <div className="mt-[20px] w-full flex justify-center">
        <button
          className="bg-blue-600 text-[16px] font-bold text-white py-[10px] px-[15px] rounded-[5px] sm:w-auto w-[80%]"
          onClick={(e) => {
            e.preventDefault();
            (type === "create" && handleCreate()) ||
              (type === "edit" && handleEdit());
          }}
        >
          Qo'shish
        </button>
      </div>
    </div>
  );
};

export default StatusForm;
