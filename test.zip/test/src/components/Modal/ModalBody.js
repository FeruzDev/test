import React, { useState } from "react";
import AboutFamilyForm from "./ModalForms/AboutFamilyForm";
import AcademicianForm from "./ModalForms/Academician";
import BachelorForm from "./ModalForms/BachelorForm";
import CertificateForm from "./ModalForms/CertificateForm";
import CityForm from "./ModalForms/CityForm";
import CompetencianForm from "./ModalForms/CompetencianForm";
import DrScience from "./ModalForms/DrScience";
import LaborActivityForm from "./ModalForms/LaborActivityForm";
import LanguageForm from "./ModalForms/LanguageForm";
import MagistracyForm from "./ModalForms/MagistracyForm";
import NationModal from "./ModalForms/NationModal";
import PhdForm from "./ModalForms/PhdForm";
import StatusForm from "./ModalForms/StatusForm";
import WorkPosForm from "./ModalForms/WorkPosForm";

const ModalBody = ({
  isVisible,
  value,
  formBody,
  type,
  closeModal,
  getDatas,
  mainModal,
}) => {
  const [closing, setClosing] = useState(false);

  const chooseFormBody = () => {
    switch (formBody) {
      case "location":
        return (
          <CityForm
            value={value}
            type={type}
            closeModal={closeModal}
            getDatas={getDatas}
            closing={closing}
            mainModal={mainModal}
          />
        );
      case "place_of_birth":
        return (
          <CityForm
            value={value}
            type={type}
            closeModal={closeModal}
            getDatas={getDatas}
            mainModal={mainModal}
          />
        );
      case "nation":
        return (
          <NationModal
            closeModal={closeModal}
            value={value}
            type={type}
            getDatas={getDatas}
            mainModal={mainModal}
          />
        );
      case "work_position":
        return (
          <WorkPosForm
            closeModal={closeModal}
            getDatas={getDatas}
            value={value}
            type={type}
            mainModal={mainModal}
          />
        );
      case "bachelor":
        return (
          <BachelorForm
            closeModal={closeModal}
            closing={closing}
            getDatas={getDatas}
            mainModal={mainModal}
            type={type}
            value={value}
          />
        );
      case "magistracy":
        return (
          <MagistracyForm
            closeModal={closeModal}
            closing={closing}
            getDatas={getDatas}
            mainModal={mainModal}
            type={type}
            value={value}
          />
        );
      case "phd":
        return (
          <PhdForm
            closeModal={closeModal}
            closing={closing}
            getDatas={getDatas}
            mainModal={mainModal}
            type={type}
            value={value}
          />
        );
      case "dr_science":
        return (
          <DrScience
            closeModal={closeModal}
            closing={closing}
            getDatas={getDatas}
            mainModal={mainModal}
            type={type}
            value={value}
          />
        );
      case "academician":
        return (
          <AcademicianForm
            closeModal={closeModal}
            closing={closing}
            getDatas={getDatas}
            mainModal={mainModal}
            type={type}
            value={value}
          />
        );
      case "tech_area":
        return (
          <CompetencianForm
            closeModal={closeModal}
            closing={closing}
            getDatas={getDatas}
            mainModal={mainModal}
            type={type}
            value={value}
          />
        );
      case "tech_area":
        return (
          <CompetencianForm
            closeModal={closeModal}
            closing={closing}
            getDatas={getDatas}
            mainModal={mainModal}
            type={type}
            value={value}
          />
        );
      case "foreign_lang":
        return (
          <LanguageForm
            closeModal={closeModal}
            closing={closing}
            getDatas={getDatas}
            mainModal={mainModal}
            type={type}
            value={value}
          />
        );
      case "labor_activity":
        return (
          <LaborActivityForm
            closeModal={closeModal}
            closing={closing}
            getDatas={getDatas}
            mainModal={mainModal}
            type={type}
            value={value}
          />
        );
      case "title_of_exp":
        return (
          <StatusForm
            closeModal={closeModal}
            closing={closing}
            getDatas={getDatas}
            mainModal={mainModal}
            type={type}
            value={value}
          />
        );
      case "about_family":
        return (
          <AboutFamilyForm
            closeModal={closeModal}
            getDatas={getDatas}
            mainModal={mainModal}
            type={type}
            value={value}
          />
        );
      case "certificate":
        return (
          <CertificateForm
            closeModal={closeModal}
            getDatas={getDatas}
            mainModal={mainModal}
            type={type}
            value={value}
          />
        );
      default:
        break;
    }
  };
  return (
    <div
      className={`${
        isVisible ? "flex" : "hidden"
      } fixed w-[100%] h-[100%] top-[0] left-[0] z-10 justify-center items-center bg-[rgba(0,0,0,0.4)]`}
      onClick={() => {
        closeModal();
        setClosing(!closing);
      }}
    >
      {chooseFormBody()}
    </div>
  );
};

export default ModalBody;
