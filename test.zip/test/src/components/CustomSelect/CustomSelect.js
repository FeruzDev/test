import React, { useEffect, useRef } from "react";
import ReactSelect from "react-select";
import { FaRegEdit } from "react-icons/fa";
import { IoAdd, IoAlertCircle } from "react-icons/io5";
import { BsPlusSquare } from "react-icons/bs";
import { selectStyles } from "./SelectStyles";

const CustomSelect = ({
  options,
  onChange,
  placeholder,
  basis,
  name,
  isValidate,
  isMulti,
  required,
  value,
  openModal,
  isNotEdited,
}) => {
  const selectRef = useRef(null);

  const validateRequire = (val) => {
    if (required) {
      if (val === null) {
        selectRef.current.controlRef.style.borderColor = "red";
        selectRef.current.controlRef.style.boxShadow = "0px 0px 0px 1px red";
      } else {
        selectRef.current.controlRef.style.borderColor = "";
        selectRef.current.controlRef.style.boxShadow = "";
      }
    }
  };

  useEffect(() => {
    if (isValidate) {
      validateRequire(value);
    }
  }, [isValidate]);

  return (
    <div className={`relative ${basis ? basis : "w-full"}`}>
      <span className="text-[14px] top-[-9px] left-[10px] px-[5px] bg-[#fff] text-[#6B7280] flex items-center">
        {placeholder}:{" "}
        {required && <IoAlertCircle style={{ marginLeft: "5px" }} />}
      </span>
      <ReactSelect
        styles={{
          ...selectStyles,
          clearIndicator: (styles) => ({
            ...styles,
            position: "relative",
            right: isNotEdited ? "5px" : "50px",
            top: "1px",
            zIndex: "2",
          }),
        }}
        components={{
          DropdownIndicator: () => null,
          IndicatorSeparator: () => null,
        }}
        options={options}
        isSearchable={false}
        value={value}
        onChange={(e) => {
          onChange(e);
          validateRequire(e);
        }}
        onBlur={() => validateRequire(value, required)}
        ref={selectRef}
        placeholder={"Tanlang..."}
        name={name}
        isClearable={true}
        isMulti={isMulti}
      />
      {!isNotEdited && (
        <div className="absolute top-[70%] right-[10px] translate-y-[-50%] flex items-center gap-[10px]">
          <FaRegEdit
            style={{
              color: "rgb(156, 156, 156)",
              cursor: "pointer",
              zIndex: 5,
            }}
            onClick={() => {
              if (!isMulti) {
                value && openModal(name, isMulti ? value[0] : value, "edit");
              } else {
                value.length > 0 &&
                  openModal(name, isMulti ? value[0] : value, "edit");
              }
            }}
          />
          <BsPlusSquare
            style={{
              color: "rgb(156, 156, 156)",
              cursor: "pointer",
              zIndex: 5,
            }}
            onClick={() => openModal(name, value, "create")}
          />
        </div>
      )}
    </div>
  );
};

export default CustomSelect;
