export const selectStyles = {
  indicatorSeparator: () => {},
  container: (styles) => ({
    ...styles,
    width: "100%",
    border: "none",
  }),
  menu: (styles) => ({
    ...styles,
    zIndex: "3",
  }),

  placeholder: (styles) => ({
    ...styles,
    fontSize: "14px",
    opacity: 0.6,
  }),
  control: (styles) => ({
    ...styles,
    borderColor: "#d1d5db",
  }),
};
