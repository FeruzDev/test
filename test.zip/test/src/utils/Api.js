import axios from "axios";

const instance = axios.create({
  baseURL: "http://192.168.0.91:8000",
});

instance.interceptors.request.use(
  (config) => {
    const userToken = localStorage.getItem("auth_token");
    if (userToken) {
      config.headers["Authorization"] = `Token ${userToken}`;
    }

    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

export default instance;
