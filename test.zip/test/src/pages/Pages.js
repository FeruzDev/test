import React from 'react'
import { Route, Routes } from 'react-router-dom'
import CreateEmployee from './CreateEmployee/CreateEmployee'

const Pages = () => {
  return (
    <Routes>
        <Route path='/' element={<CreateEmployee/>} />
    </Routes>
  )
}

export default Pages
