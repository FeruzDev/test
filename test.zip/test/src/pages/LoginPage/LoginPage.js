import React, { useState } from "react";
import FormBtn from "../../components/FormBtn/FormBtn";
import FormInput from "../../components/FormInput/FormInput";
import Api from "../../utils/Api";

const LoginPage = ({ setIsLoged }) => {
  const [username, setUsername] = useState(null);
  const [password, setPassword] = useState(null);

  const handleChangeUsername = (e) => {
    setUsername(e.target.value);
  };

  const handleChangePassword = (e) => {
    setPassword(e.target.value);
  };

  const handleLogin = async (e) => {
    try {
      e.preventDefault();
      let body = {
        username: username,
        password: password,
      };
      const response = await Api.post("/auth/token/login/", body);
      localStorage.setItem("auth_token", response?.data?.auth_token);
      setIsLoged(true);
    } catch (error) {
      return console.log(error);
    }
  };

  return (
    <div
      style={{
        background: "linear-gradient(to bottom, #0f0c29, #302b63, #24243e)",
      }}
      className="login_page"
    >
      <form className="form_block">
        <h1 className="form_head">LogIn</h1>
        <div className="form_content">
          <FormInput
            placeholder={"Username"}
            type={"text"}
            onChange={handleChangeUsername}
          />
          <FormInput
            placeholder={"Password"}
            type={"password"}
            onChange={handleChangePassword}
          />
        </div>
        <div className="form_content">
          <FormBtn title={"LogIn"} onClick={handleLogin} />
        </div>
      </form>
    </div>
  );
};

export default LoginPage;
