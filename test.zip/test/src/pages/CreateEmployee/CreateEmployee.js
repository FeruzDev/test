import React, { useEffect, useState } from "react";
import CustomCheckBox from "../../components/CustomCheckBox/CustomCheckBox";
import CustomInput from "../../components/CustomInput/CustomInput";
import CustomSelect from "../../components/CustomSelect/CustomSelect";
import CustomDatePicker from "../../components/DatePicker/CustomDatePicker";
import FileUpload from "../../components/FileUpload/FileUpload";
import {
  errorToast,
  successToast,
} from "../../components/ToastMessage/ToastMessage";
import { fetchAboutFamily } from "../../http/aboutFamilyApi";
import { fetchAcademican } from "../../http/academicanApi";
import { fetchBachelor } from "../../http/bachelorApi";
import { fetchCertificate } from "../../http/certificateApi";
import { fetchCity } from "../../http/cityApi";
import { fetchCompetency } from "../../http/competencyApi";
import { fetchConfilctOfInterest } from "../../http/conflictOfInterestApi";
import { fetchDrScience } from "../../http/drScience";
import { fetchForeignLanguages } from "../../http/foreignLanguages";
import { fetchLaborActivity } from "../../http/laborActivityApi";
import { fetchMagistracy } from "../../http/magistracyApi";
import { fetchNation } from "../../http/nationApi";
import { fetchPhd } from "../../http/phdApi";
import { fetchPosition } from "../../http/positionApi";
import { fetchStatus } from "../../http/statusApi";
import { fetchUserList } from "../../http/userApi";
import { validateSendData } from "./utils/validateSendData";
import Api from "../../utils/Api";
import {
  changeData,
  changeDateFormat,
  changeEduData,
  changeListValues,
  changeMultiValues,
  createFormData,
  multiSelectValue,
  selectValue,
} from "./utils/utils";
import ModalBody from "../../components/Modal/ModalBody";

const CreateEmployee = () => {
  // Lists
  const [userList, setUserList] = useState([]);
  const [locationList, setLocationList] = useState([]);
  const [nationList, setNationList] = useState([]);
  const [workPositionList, setWorkPositionList] = useState([]);
  const [recommendationList, setRecommendationList] = useState([]);
  const [bachelorList, setBachelorList] = useState([]);
  const [magistracyList, setMagistracyList] = useState([]);
  const [doctorScienceList, setDoctorScienceList] = useState([]);
  const [academicianList, setAcademicianList] = useState([]);
  const [competenceList, setCompetenceList] = useState([]);
  const [foreignLangList, setForeignLangList] = useState([]);
  const [laborActivityList, setLaborActivityList] = useState([]);
  const [statusList, setStatusList] = useState([]);
  const [relativesInfoList, setRelativesInfoList] = useState([]);
  const [certificateList, setCertificateList] = useState([]);
  const [conflictsList, setConflictsList] = useState([]);
  const [phdList, setPhdList] = useState([]);

  // For Inputs
  const [address, setAddress] = useState("");
  const [number, setNumber] = useState("");
  const [experience, setExperience] = useState("");
  const [auditCount, setAuditCount] = useState("");
  const [partition, setPartition] = useState("");
  const [militarySpecialRank, setMilitarySpecialRank] = useState("");
  const [graduateByGov, setGraduateByGov] = useState("");
  const [work, setWork] = useState("");
  const [factLivePlace, setFactLivePlace] = useState("");
  const [centreAgree, setCentreAgree] = useState("");
  const [lastWork, setLastWork] = useState("");

  // For Select
  const [user, setUser] = useState(null);
  const [location, setLocation] = useState(null);
  const [nation, setNation] = useState(null);
  const [workPosition, setWorkPosition] = useState(null);
  const [recommendation, setRecommendation] = useState(null);
  const [bachelor, setBachelor] = useState(null);
  const [magistracy, setMagistracy] = useState(null);
  const [doctorScience, setDoctorScience] = useState(null);
  const [academician, setAcademican] = useState(null);
  const [placeOfBirth, setPlaceOfBirth] = useState(null);
  const [phd, setPhd] = useState(null);

  // For MultiSelect
  const [competence, setCompetence] = useState(null);
  const [foreignLang, setForeignLang] = useState(null);
  const [laborActivity, setLaborActivity] = useState(null);
  const [status, setStatus] = useState(null);
  const [relativesInfo, setRelativesInfo] = useState(null);
  const [certificate, setCertificate] = useState(null);
  const [conflicts, setConflicts] = useState(null);

  // For Datepicker
  const [startAtAcrred, setStartAtAccred] = useState(null);
  const [firstWorkingDate, setFirstWorkingDate] = useState(null);
  const [birthdate, setBirthdate] = useState(null);

  // For CheckBox
  const [statusCentreAgree, setStatusCentreAgree] = useState(false);
  const [wasFired, setWasFired] = useState(false);

  // For FileUpoad
  const [resume, setResume] = useState();
  const [photo, setPhoto] = useState();

  // Validate all inputs
  const [isValidate, setIsValidate] = useState(false);

  // Clear state
  const [isClear, setIsClear] = useState(false);

  // states for modals
  const [modal, setModal] = useState(false);
  const [valueForModal, setValueForModal] = useState(null);
  const [typeForModal, setTypeForModal] = useState(null);
  const [bodyModal, setBodyModal] = useState(null);

  const clearForm = () => {
    setAddress("");
    setNumber("");
    setExperience("");
    setAuditCount("");
    setPartition("");
    setMilitarySpecialRank("");
    setGraduateByGov("");
    setWork("");
    setFactLivePlace("");
    setCentreAgree("");
    setLastWork("");
    setUser(null);
    setLocation(null);
    setNation(null);
    setWorkPosition(null);
    setRecommendation(null);
    setBachelor(null);
    setMagistracy(null);
    setDoctorScience(null);
    setAcademican(null);
    setPlaceOfBirth(null);
    setPhd(null);
    setCompetence(null);
    setForeignLang(null);
    setLaborActivity(null);
    setStatus(null);
    setRelativesInfo(null);
    setCertificate(null);
    setConflicts(null);
    setStartAtAccred(null);
    setFirstWorkingDate(null);
    setBirthdate(null);
    setStatusCentreAgree(false);
    setWasFired(false);
    setResume(null);
    setPhoto(null);
    //
    setIsClear(true);
    setTimeout(() => {
      setIsClear(false);
    }, 1000);
  };

  const createEmployee = async (body) => {
    const { data } = await Api.post("/apps/employees/create/", body);
    return data;
  };

  const handleOpenModal = (body, val, type) => {
    setValueForModal(val);
    setTypeForModal(type);
    setBodyModal(body);
    setModal(true);
  };

  // Create Employee
  const handleCreate = (e) => {
    e.preventDefault();
    const body = {
      address: address,
      phone_number: number,
      work: work,
      start_at_accreditation: changeDateFormat(startAtAcrred),
      partition: partition,
      military_special_rank: militarySpecialRank,
      graduate_by_government: graduateByGov,
      birthday: changeDateFormat(birthdate),
      fact_live_place: factLivePlace,
      last_work: lastWork,
      work_xp: experience,
      audit_count: auditCount,
      agree_status: statusCentreAgree,
      first_working_date: changeDateFormat(firstWorkingDate),
      centre_agree: centreAgree,
      is_fired: wasFired,
      user: changeListValues(user),
      place_of_birth: changeListValues(placeOfBirth),
      nation: changeListValues(nation),
      bachelor: changeListValues(bachelor),
      magistracy: changeListValues(magistracy),
      phd: changeListValues(phd),
      doctor_science: changeListValues(doctorScience),
      academician: changeListValues(academician),
      work_position: changeListValues(workPosition),
      location: changeListValues(location),
      recommendation: changeListValues(recommendation),
      tech_area: changeMultiValues(competence),
      foreign_lang: changeMultiValues(foreignLang),
      labor_activity: changeMultiValues(laborActivity),
      about_family: changeMultiValues(relativesInfo),
      title_of_exp: changeMultiValues(status),
      certificate: changeMultiValues(certificate),
      conflict_of_interest: changeMultiValues(conflicts),
      photo_pic: photo,
      resume: resume,
    };
    setIsValidate(true);
    if (validateSendData(body)) {
      const formDataBody = createFormData(body);
      createEmployee(formDataBody)
        .then(() => {
          successToast("Данные успешно отправлены!");
          clearForm();
        })
        .catch((error) => errorToast(error.message));
    } else {
      errorToast("Заполните обязательные поля");
    }
  };

  // get datas
  const getDatas = () => {
    fetchAboutFamily().then((data) =>
      setRelativesInfoList(
        data.map((el) => ({ ...el, label: el.full_name, value: el.id }))
      )
    );
    fetchUserList().then((data) => {
      setUserList(
        data.map((el) => ({ ...el, label: el.full_name, value: el.id }))
      );
      setRecommendationList(
        data.map((el) => ({ ...el, label: el.full_name, value: el.id }))
      );
    });
    fetchCity().then((data) => {
      setLocationList(
        data.map((el) => ({
          ...el,
          label: `${el.country.name} - ${el.name}`,
          value: el.id,
        }))
      );
    });
    fetchNation().then((data) => changeData(data, setNationList));
    fetchPosition().then((data) => changeData(data, setWorkPositionList));
    fetchBachelor().then((data) => changeEduData(data, setBachelorList));
    fetchMagistracy().then((data) => changeEduData(data, setMagistracyList));
    fetchDrScience().then((data) => changeEduData(data, setDoctorScienceList));
    fetchAcademican().then((data) => changeEduData(data, setAcademicianList));
    fetchPhd().then((data) => changeEduData(data, setPhdList));
    fetchCompetency().then((data) =>
      setCompetenceList(
        data.map((el) => ({
          ...el,
          label: `${el.code.name} ${el.name_code}`,
          value: el.id,
        }))
      )
    );
    fetchForeignLanguages().then((data) =>
      setForeignLangList(
        data.map((el) => ({ ...el, label: el.lang, value: el.id }))
      )
    );
    fetchLaborActivity().then((data) => changeData(data, setLaborActivityList));
    fetchStatus().then((data) => changeData(data, setStatusList));
    fetchCertificate().then((data) =>
      setCertificateList(
        data.map((el) => ({
          ...el,
          label: `${el.name} ${el.person}`,
          value: el.id,
        }))
      )
    );
    fetchConfilctOfInterest().then((data) =>
      setConflictsList(
        data.map((el) => ({
          ...el,
          label: `${el.name} ${el.reason}`,
          value: el.id,
        }))
      )
    );
  };

  useEffect(() => {
    getDatas();
  }, []);

  return (
    <>
      <div className="max-w-[1240px] px-[20px] py-[30px] my-0 mx-auto flex items-center">
        <form className="border-2 shadow-xl rounded-[10px] w-full min-h-[800px] p-[20px]">
          <h3 className="font-bold text-[28px] text-black mb-[20px]">
            Xodimni qo'shish
          </h3>
          <div className="form_row">
            <CustomSelect
              options={userList}
              placeholder={"Foydalanuvchi"}
              value={user}
              onChange={(e) => selectValue(e, setUser)}
              required
              isValidate={isValidate}
              name="user"
              isNotEdited={true}
            />
            <CustomInput
              label={"Telefon raqami"}
              onChange={(e) => setNumber(e.target.value)}
              value={number}
              placeholder="+998912345678"
              type={"number"}
              required
              isValidate={isValidate}
              name="phone_number"
            />
            <CustomDatePicker
              value={birthdate}
              label="Tugilgan sana"
              onChange={(e) => setBirthdate(e)}
              required
              isValidate={isValidate}
              name="birthday"
            />
          </div>
          <div className="form_row">
            <CustomSelect
              options={locationList}
              placeholder={"Lokatsiya"}
              value={location}
              onChange={(e) => selectValue(e, setLocation)}
              required
              isValidate={isValidate}
              name="location"
              openModal={handleOpenModal}
            />
            <CustomDatePicker
              label={"Akkreditatsiya sohasidagi faoliyatning boshlanishi"}
              value={startAtAcrred}
              onChange={(e) => setStartAtAccred(e)}
              required
              isValidate={isValidate}
              name="start_at_accreditation"
            />
            <CustomDatePicker
              label={"Birinchi ishga qabul qilingan sana"}
              value={firstWorkingDate}
              onChange={(e) => setFirstWorkingDate(e)}
              required
              isValidate={isValidate}
              name="first_working_date"
            />
          </div>
          <div className="form_row">
            <CustomSelect
              placeholder={"Passportagi propiska manzili"}
              options={locationList}
              value={placeOfBirth}
              onChange={(e) => selectValue(e, setPlaceOfBirth)}
              required
              isValidate={isValidate}
              name="place_of_birth"
              openModal={handleOpenModal}
            />
            <CustomSelect
              placeholder={"Millati"}
              options={nationList}
              value={nation}
              onChange={(e) => selectValue(e, setNation)}
              required
              isValidate={isValidate}
              name="nation"
              openModal={handleOpenModal}
            />
            <CustomSelect
              placeholder={"Lavozimi"}
              options={workPositionList}
              value={workPosition}
              onChange={(e) => selectValue(e, setWorkPosition)}
              required
              isValidate={isValidate}
              name="work_position"
              openModal={handleOpenModal}
            />
          </div>
          <div className="form_row">
            <CustomInput
              label="Ish tajribasi"
              type={"number"}
              onChange={(e) =>
                setExperience((e.target.value && Number(e.target.value)) || "")
              }
              value={experience}
              placeholder="99"
              isValidate={isValidate}
              name="work_xp"
            />
            <CustomInput
              label="Auditlar soni"
              type={"number"}
              onChange={(e) =>
                setAuditCount((e.target.value && Number(e.target.value)) || "")
              }
              value={auditCount}
              placeholder="99"
              isValidate={isValidate}
              name="audit_count"
            />
            <CustomSelect
              placeholder={"Kim tavsiya bergan?"}
              options={recommendationList}
              value={recommendation}
              onChange={(e) => selectValue(e, setRecommendation)}
              isValidate={isValidate}
              name="recommendation"
              required={true}
              isNotEdited={true}
            />
          </div>
          <div className="form_row">
            <CustomSelect
              options={bachelorList}
              value={bachelor}
              onChange={(e) => selectValue(e, setBachelor)}
              placeholder="Bakalavriat"
              required
              isValidate={isValidate}
              name="bachelor"
              openModal={handleOpenModal}
            />
            <CustomSelect
              value={magistracy}
              onChange={(e) => selectValue(e, setMagistracy)}
              options={magistracyList}
              placeholder="Magistratura"
              isValidate={isValidate}
              name="magistracy"
              openModal={handleOpenModal}
            />
            <CustomSelect
              value={phd}
              onChange={(e) => selectValue(e, setPhd)}
              options={phdList}
              placeholder="Aspirantura"
              isValidate={isValidate}
              name="phd"
              openModal={handleOpenModal}
            />
          </div>
          <div className="form_row">
            <CustomSelect
              value={doctorScience}
              onChange={(e) => selectValue(e, setDoctorScience)}
              options={doctorScienceList}
              placeholder="Doktorantura"
              isValidate={isValidate}
              name="dr_science"
              openModal={handleOpenModal}
            />
            <CustomSelect
              value={academician}
              onChange={(e) => selectValue(e, setAcademican)}
              options={academicianList}
              placeholder="Akademik"
              isValidate={isValidate}
              name="academician"
              openModal={handleOpenModal}
            />
            <CustomInput
              label="Partiyaga a'zolik"
              onChange={(e) => setPartition(e.target.value)}
              value={partition}
              placeholder='"Milliy tiklanish"'
              isValidate={isValidate}
              name="partition"
            />
          </div>
          <div className="form_row">
            <CustomInput
              label="Harbiy (maxsus) unvon"
              onChange={(e) => setMilitarySpecialRank(e.target.value)}
              value={militarySpecialRank}
              placeholder="Serjant"
              isValidate={isValidate}
              name="military_special_rank"
            />
            <CustomInput
              label="Davlat mukofotlari bilan taqdirlanganmi?"
              onChange={(e) => setGraduateByGov(e.target.value)}
              value={graduateByGov}
              placeholder='"Oʻzbekiston Qahramoni"'
              isValidate={isValidate}
              name="graduate_by_government"
            />
            <CustomInput
              label="Yashash joyi"
              onChange={(e) => setAddress(e.target.value)}
              value={address}
              placeholder="Islom Karimov ko'chasi 12 uy"
              required
              isValidate={isValidate}
              name="address"
            />
          </div>
          <div className="form_row">
            <CustomInput
              label="Ish joyi"
              onChange={(e) => setWork(e.target.value)}
              value={work}
              placeholder="Islom Karimov ko'chasi 12 uy"
              required
              isValidate={isValidate}
              name="work"
            />
            <CustomInput
              label="Haqiqiy yashash manzili"
              onChange={(e) => setFactLivePlace(e.target.value)}
              value={factLivePlace}
              placeholder="Islom Karimov ko'chasi 12 uy"
              required
              isValidate={isValidate}
              name="fact_live_place"
            />
            <CustomInput
              label="Markaz bilan bog'liq shartnoma"
              onChange={(e) => setCentreAgree(e.target.value)}
              value={centreAgree}
              required
              isValidate={isValidate}
              name="centre_agree"
            />
          </div>
          <div className="form_row">
            <CustomInput
              label="Oxirgi ish joyi"
              onChange={(e) => setLastWork(e.target.value)}
              value={lastWork}
              placeholder="OOO NGMK"
              isValidate={isValidate}
              name="last_work"
            />
            <CustomSelect
              options={competenceList}
              isMulti={true}
              value={competence}
              onChange={(e) => multiSelectValue(e, setCompetence)}
              placeholder="Kompetentsiya (kodi)"
              isValidate={isValidate}
              name="tech_area"
              openModal={handleOpenModal}
            />
            <CustomSelect
              options={foreignLangList}
              isMulti={true}
              value={foreignLang}
              onChange={(e) => multiSelectValue(e, setForeignLang)}
              placeholder="Chet tillar"
              isValidate={isValidate}
              name="foreign_lang"
              openModal={handleOpenModal}
            />
          </div>
          <div className="form_row">
            <CustomSelect
              options={laborActivityList}
              isMulti={true}
              value={laborActivity}
              onChange={(e) => multiSelectValue(e, setLaborActivity)}
              placeholder="Kasblar"
              isValidate={isValidate}
              name="labor_activity"
              openModal={handleOpenModal}
            />
            <CustomSelect
              options={statusList}
              isMulti={true}
              value={status}
              onChange={(e) => multiSelectValue(e, setStatus)}
              placeholder="Status"
              isValidate={isValidate}
              required
              name="title_of_exp"
              openModal={handleOpenModal}
            />
            <CustomSelect
              options={relativesInfoList}
              isMulti={true}
              value={relativesInfo}
              onChange={(e) => multiSelectValue(e, setRelativesInfo)}
              placeholder="Yaqin qarindoshlar haqida ma'lumot"
              isValidate={isValidate}
              name="about_family"
              openModal={handleOpenModal}
            />
          </div>
          <div className="form_row">
            <CustomSelect
              options={certificateList}
              isMulti={true}
              value={certificate}
              placeholder="Sertifikat va guvohnomalar"
              onChange={(e) => multiSelectValue(e, setCertificate)}
              isValidate={isValidate}
              name="certificate"
              openModal={handleOpenModal}
            />
            <CustomSelect
              options={conflictsList}
              isMulti={true}
              value={conflicts}
              placeholder="Manfaatlar to'qnashuvi"
              onChange={(e) => multiSelectValue(e, setConflicts)}
              isValidate={isValidate}
              name="conflict_of_interest"
            />
            <CustomCheckBox
              label={"Markaz bilan kelishuv holati"}
              value={statusCentreAgree}
              onChange={(e) => setStatusCentreAgree(e.target.checked)}
              name="agree_status"
            />
          </div>
          <div className="form_row">
            <FileUpload
              label={"Rasm"}
              onChange={(e) => setPhoto(e.target.files[0])}
              required
              isValidate={isValidate}
              name="photo_pic"
              value={photo}
              isClear={isClear}
            />
            <FileUpload
              label={"Rezume"}
              onChange={(e) => setResume(e.target.files[0])}
              required
              isValidate={isValidate}
              name="resume"
              value={photo}
              isClear={isClear}
            />
            <CustomCheckBox
              label={"Xodim ishdan bo'shatilganmi?"}
              value={wasFired}
              onChange={(e) => setWasFired(e.target.checked)}
              name="is_fired"
            />
          </div>
          <div className="mt-[20px] w-full flex sm:justify-end  justify-center">
            <button
              className="bg-blue-600 text-[16px] font-bold text-white py-[10px] px-[15px] rounded-[5px] sm:w-auto w-[80%]"
              onClick={(e) => handleCreate(e)}
              type="submit"
            >
              Qo'shish
            </button>
          </div>
        </form>
      </div>
      <ModalBody
        isVisible={modal}
        value={valueForModal}
        formBody={bodyModal}
        type={typeForModal}
        closeModal={() => setModal(false)}
        getDatas={getDatas}
        mainModal={modal}
      />
    </>
  );
};

export default CreateEmployee;
