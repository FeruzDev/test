const requiredKeys = [
  "address",
  "phone_number",
  "work",
  "start_at_accreditation",
  "birthday",
  "fact_live_place",
  "first_working_date",
  "centre_agree",
  "user",
  "place_of_birth",
  "nation",
  "bachelor",
  "work_position",
  "location",
  "title_of_exp",
  "resume",
  "photo_pic",
];

export const validateSendData = (body) => {
  for (const key in body) {
    if (requiredKeys.includes(key)) {
      if (!body[key]) {
        return false;
      }
    }
    if (!body[key]) {
      delete body[key];
    }
  }
  return true;
};
