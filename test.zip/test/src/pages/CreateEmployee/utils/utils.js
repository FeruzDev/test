export const changeMultiValues = (arr) => {
  return arr && arr.map((el) => el.value);
};

export const changeListValues = (obj) => {
  return (obj && obj.value) || null;
};

const listData = [
  "title_of_exp",
  "conflict_of_interest",
  "certificate",
  "about_family",
  "labor_activity",
  "foreign_lang",
  "tech_area",
];
export const createFormData = (body) => {
  let formData = new FormData();
  for (const key in body) {
    if (listData.includes(key)) {
      body[key].forEach((el) => {
        formData.append(key, el);
      });
    } else {
      formData.append(key, body[key]);
    }
  }
  return formData;
};

export const changeDateFormat = (date) => {
  const strDate = new Date(date).toISOString();
  return strDate.slice(0, strDate.indexOf("T"));
};

export const selectValue = (e, callback) => {
  callback(e);
};

export const multiSelectValue = (e, callback) => {
  callback(e);
};

export const changeEduData = (data, setValue) => {
  setValue([
    ...data.map((item) => ({
      ...item,
      label: `${item.education?.university?.name} - ${item.education?.graduate}`,
      value: item.id,
    })),
  ]);
};

export const changeData = (data, setValue) => {
  setValue([
    ...data.map((item) => ({
      ...item,
      label: item.name,
      value: item.id,
    })),
  ]);
};
